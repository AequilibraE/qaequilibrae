import sys
from os.path import abspath, join, dirname

sys.path.insert(0, abspath(join(dirname(dirname(__file__)), "")))
